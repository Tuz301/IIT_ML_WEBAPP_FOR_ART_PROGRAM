// src/pages/ModelMetrics.tsx
import { motion } from 'framer-motion';

export const ModelMetrics = () => {
  const metrics = [
    { name: 'AUC Score', value: '85.0%', description: 'Area Under Curve' },
    { name: 'Precision', value: '78.0%', description: 'Positive Predictive Value' },
    { name: 'Recall', value: '82.0%', description: 'Sensitivity' },
    { name: 'F1 Score', value: '80.0%', description: 'Balance Score' },
    { name: 'Sensitivity', value: '82.0%', description: 'True Positive Rate' },
    { name: 'Specificity', value: '88.0%', description: 'True Negative Rate' },
  ];

  const confusionMatrix = {
    trueNegative: 894,
    falsePositive: 67,
    falseNegative: 53,
    truePositive: 233,
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Model Performance Metrics
          </h1>
          <p className="text-gray-600">
            Real-time insights into the ML model's prediction accuracy
          </p>
        </motion.div>

        {/* Metrics Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8"
        >
          {metrics.map((metric, index) => (
            <div
              key={metric.name}
              className="bg-white rounded-xl p-4 text-center shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
            >
              <div className="text-2xl font-bold text-blue-600 mb-1">
                {metric.value}
              </div>
              <div className="text-sm font-medium text-gray-900 mb-1">
                {metric.name}
              </div>
              <div className="text-xs text-gray-500">
                {metric.description}
              </div>
            </div>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Confusion Matrix */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
          >
            <h2 className="text-xl font-semibold text-gray-900 mb-6">
              Confusion Matrix
            </h2>
            
            <div className="overflow-hidden rounded-lg border border-gray-200">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actual \ Predicted
                    </th>
                    <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Negative
                    </th>
                    <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Positive
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 bg-red-50">
                      Actual Negative
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center bg-green-50">
                      <div className="font-semibold text-green-700">{confusionMatrix.trueNegative}</div>
                      <div className="text-xs text-green-600">True Negative</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center bg-red-50">
                      <div className="font-semibold text-red-700">{confusionMatrix.falsePositive}</div>
                      <div className="text-xs text-red-600">False Positive</div>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 bg-green-50">
                      Actual Positive
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center bg-red-50">
                      <div className="font-semibold text-red-700">{confusionMatrix.falseNegative}</div>
                      <div className="text-xs text-red-600">False Negative</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center bg-green-50">
                      <div className="font-semibold text-green-700">{confusionMatrix.truePositive}</div>
                      <div className="text-xs text-green-600">True Positive</div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </motion.div>

          {/* Model Information */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
          >
            <h2 className="text-xl font-semibold text-gray-900 mb-6">
              Model Information
            </h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-600">Model Version</h3>
                <p className="text-gray-900 font-semibold">v2.1.0 - Treatment Interruption Predictor</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-600">Training Date</h3>
                <p className="text-gray-900">October 15, 2024</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-600">Algorithm</h3>
                <p className="text-gray-900">XGBoost Classifier</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-600">Training Dataset</h3>
                <p className="text-gray-900">12,345 patient records</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-600">Last Updated</h3>
                <p className="text-gray-900">3 days ago</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};