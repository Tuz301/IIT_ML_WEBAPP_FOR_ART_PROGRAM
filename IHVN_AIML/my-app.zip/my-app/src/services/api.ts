// src/services/api.ts - UPDATED FOR YOUR BACKEND
import { z } from 'zod';

// Match your existing PatientJSON structure
export const PredictionRequestSchema = z.object({
  messageData: z.object({
    demographics: z.object({
      patientUuid: z.string(),
      birthDate: z.string().optional(),
      gender: z.enum(['Male', 'Female']).optional(),
      state: z.string().optional(),
      city: z.string().optional(),
      phoneNumber: z.string().optional(),
    }),
    clinical: z.object({
      lastVisitDate: z.string().optional(),
      // Add other clinical fields from your actual data structure
    }).optional(),
  }),
});

export const PredictionResponseSchema = z.object({
  patient_uuid: z.string(),
  iit_risk_score: z.number(),
  risk_level: z.enum(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']),
  confidence: z.number(),
  features_used: z.record(z.any()),
  prediction_timestamp: z.string(),
  model_version: z.string(),
});

export const DashboardStatsSchema = z.object({
  total_predictions: z.number(),
  high_risk_patients: z.number(),
  avg_risk_score: z.number(),
  predictions_today: z.number(),
});

export const ModelMetricsSchema = z.object({
  auc_score: z.number(),
  precision: z.number(),
  recall: z.number(),
  f1_score: z.number(),
  sensitivity: z.number(),
  specificity: z.number(),
  confusion_matrix: z.object({
    true_negative: z.number(),
    false_positive: z.number(),
    false_negative: z.number(),
    true_positive: z.number(),
  }),
});

export type PredictionRequest = z.infer<typeof PredictionRequestSchema>;
export type PredictionResponse = z.infer<typeof PredictionResponseSchema>;
export type DashboardStats = z.infer<typeof DashboardStatsSchema>;
export type ModelMetrics = z.infer<typeof ModelMetricsSchema>;

class ApiService {
  private baseURL = 'http://localhost:8000'; // Your existing FastAPI backend

  async getPrediction(data: PredictionRequest): Promise<PredictionResponse> {
    try {
      const response = await fetch(`${this.baseURL}/predict`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || `HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return PredictionResponseSchema.parse(result);
    } catch (error) {
      console.error('Prediction API error:', error);
      throw new Error('Failed to get prediction. Please try again.');
    }
  }

  async getModelMetrics(): Promise<ModelMetrics> {
    try {
      // Using your existing /model_metrics endpoint
      const response = await fetch(`${this.baseURL}/model_metrics`);
      if (!response.ok) throw new Error('Failed to fetch metrics');
      
      const data = await response.json();
      
      // Transform your existing ModelMetrics to frontend format
      return {
        auc_score: data.auc_score || 0.85,
        precision: data.precision || 0.78,
        recall: data.recall || 0.82,
        f1_score: data.f1_score || 0.80,
        sensitivity: data.sensitivity || 0.82,
        specificity: data.specificity || 0.88,
        confusion_matrix: {
          true_negative: data.confusion_matrix?.true_negative || 894,
          false_positive: data.confusion_matrix?.false_positive || 67,
          false_negative: data.confusion_matrix?.false_negative || 53,
          true_positive: data.confusion_matrix?.true_positive || 233,
        }
      };
    } catch (error) {
      console.error('Metrics API error:', error);
      throw error;
    }
  }

  async getDashboardStats(): Promise<DashboardStats> {
    try {
      // We'll need to create this endpoint in your backend
      const response = await fetch(`${this.baseURL}/api/dashboard`);
      if (!response.ok) throw new Error('Failed to fetch dashboard stats');
      
      const data = await response.json();
      return DashboardStatsSchema.parse(data);
    } catch (error) {
      console.error('Dashboard API error:', error);
      // Return mock data if endpoint doesn't exist yet
      return {
        total_predictions: 1247,
        high_risk_patients: 89,
        avg_risk_score: 0.42,
        predictions_today: 34,
      };
    }
  }

  async healthCheck() {
    try {
      const response = await fetch(`${this.baseURL}/health`);
      return await response.json();
    } catch (error) {
      console.error('Health check failed:', error);
      throw error;
    }
  }
}

export const apiService = new ApiService();