// src/components/Navigation.tsx - Updated with theme toggle
import { Link, useLocation } from 'react-router-dom';
import { 
  HomeIcon, 
  ChartBarIcon, 
  PlusCircleIcon,
  HeartIcon 
} from '@heroicons/react/24/outline';
import { ThemeToggle } from './ThemeToggle';

export const Navigation = () => {
  const location = useLocation();

  const navigation = [
    { name: 'Dashboard', href: '/', icon: HomeIcon, current: location.pathname === '/' },
    { name: 'Model Metrics', href: '/metrics', icon: ChartBarIcon, current: location.pathname === '/metrics' },
    { name: 'New Prediction', href: '/predict', icon: PlusCircleIcon, current: location.pathname === '/predict' },
  ];

  return (
    <nav className="bg-white dark:bg-gray-800 shadow-lg border-b border-gray-200 dark:border-gray-700 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <HeartIcon className="h-8 w-8 text-red-600 dark:text-red-500 mr-2" />
              <span className="font-bold text-xl text-gray-900 dark:text-white">
                IIT Predictor
              </span>
            </div>
            <div className="hidden md:ml-8 md:flex md:space-x-4">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`inline-flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    item.current
                      ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 border-b-2 border-blue-600 dark:border-blue-400'
                      : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <item.icon className="h-4 w-4 mr-2" />
                  {item.name}
                </Link>
              ))}
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <div className="hidden md:block text-sm text-gray-500 dark:text-gray-400">
              Last sync: Today 11:45 AM
            </div>
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-semibold">
              DR
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};