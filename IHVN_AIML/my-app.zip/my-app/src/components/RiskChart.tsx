import { motion } from 'framer-motion';
import { BarChart3 } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function RiskChart() {
  const [data, setData] = useState([
    { label: 'Low', value: 0, color: 'bg-green-500', percentage: 48 },
    { label: 'Medium', value: 0, color: 'bg-amber-500', percentage: 28 },
    { label: 'High', value: 0, color: 'bg-orange-500', percentage: 17 },
    { label: 'Critical', value: 0, color: 'bg-red-500', percentage: 7 },
  ]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setData([
        { label: 'Low', value: 598, color: 'bg-green-500', percentage: 48 },
        { label: 'Medium', value: 349, color: 'bg-amber-500', percentage: 28 },
        { label: 'High', value: 212, color: 'bg-orange-500', percentage: 17 },
        { label: 'Critical', value: 88, color: 'bg-red-500', percentage: 7 },
      ]);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const maxValue = Math.max(...data.map(d => d.value));

  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
            <BarChart3 className="w-4 h-4 text-blue-600" />
          </div>
          Risk Distribution
        </h3>
        <span className="text-sm text-slate-500 font-medium">Last 30 days</span>
      </div>

      <div className="space-y-4">
        {data.map((item, index) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 + 0.3 }}
            className="space-y-2"
          >
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-slate-700">{item.label} Risk</span>
              <div className="flex items-center gap-3">
                <span className="text-slate-500">{item.value} patients</span>
                <span className="font-semibold text-slate-800 w-12 text-right">
                  {item.percentage}%
                </span>
              </div>
            </div>
            
            <div className="relative h-8 bg-slate-100 rounded-full overflow-hidden">
              <motion.div
                className={`h-full ${item.color} rounded-full relative`}
                initial={{ width: 0 }}
                animate={{ width: `${item.percentage}%` }}
                transition={{ duration: 1, delay: index * 0.1 + 0.5, ease: 'easeOut' }}
              >
                <div className="absolute inset-0 bg-white/20" />
              </motion.div>
            </div>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-100"
      >
        <p className="text-sm text-blue-800">
          <span className="font-semibold">Insight:</span> 76% of patients are in low to medium risk categories. 
          Focus retention efforts on the 24% high-risk population for maximum impact.
        </p>
      </motion.div>
    </div>
  );
}
