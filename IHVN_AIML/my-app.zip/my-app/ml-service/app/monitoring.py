"""
Prometheus metrics and monitoring utilities
"""
from prometheus_client import Counter, Histogram, Gauge, Info
import time
from functools import wraps
from typing import Callable


# Prediction Metrics
prediction_requests_total = Counter(
    'iit_prediction_requests_total',
    'Total number of prediction requests',
    ['endpoint', 'status']
)

prediction_duration_seconds = Histogram(
    'iit_prediction_duration_seconds',
    'Time spent processing predictions',
    ['endpoint'],
    buckets=[0.01, 0.05, 0.1, 0.5, 1.0, 2.5, 5.0, 10.0]
)

prediction_risk_distribution = Counter(
    'iit_prediction_risk_distribution',
    'Distribution of predicted risk levels',
    ['risk_level']
)

batch_size_distribution = Histogram(
    'iit_batch_size_distribution',
    'Distribution of batch prediction sizes',
    buckets=[1, 5, 10, 25, 50, 100]
)

# Model Metrics
model_inference_latency = Histogram(
    'iit_model_inference_latency_seconds',
    'Model inference latency',
    buckets=[0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1.0]
)

feature_extraction_latency = Histogram(
    'iit_feature_extraction_latency_seconds',
    'Feature extraction latency',
    buckets=[0.01, 0.05, 0.1, 0.5, 1.0, 2.0]
)

model_predictions_total = Counter(
    'iit_model_predictions_total',
    'Total predictions made by the model',
    ['model_version']
)

# System Metrics
redis_operations_total = Counter(
    'iit_redis_operations_total',
    'Total Redis operations',
    ['operation', 'status']
)

redis_latency_seconds = Histogram(
    'iit_redis_latency_seconds',
    'Redis operation latency',
    ['operation'],
    buckets=[0.001, 0.005, 0.01, 0.05, 0.1]
)

api_errors_total = Counter(
    'iit_api_errors_total',
    'Total API errors',
    ['endpoint', 'error_type']
)

# Model Performance Metrics
model_auc_score = Gauge(
    'iit_model_auc_score',
    'Current model AUC score'
)

model_drift_detected = Gauge(
    'iit_model_drift_detected',
    'Model drift detection flag (0=no drift, 1=drift detected)'
)

# Application Info
app_info = Info(
    'iit_service_info',
    'IIT ML Service information'
)

# System Health
system_uptime_seconds = Gauge(
    'iit_system_uptime_seconds',
    'System uptime in seconds'
)

feature_store_cache_hits = Counter(
    'iit_feature_store_cache_hits_total',
    'Feature store cache hits'
)

feature_store_cache_misses = Counter(
    'iit_feature_store_cache_misses_total',
    'Feature store cache misses'
)


def track_prediction_time(endpoint: str):
    """Decorator to track prediction processing time"""
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            start_time = time.time()
            status = "success"
            
            try:
                result = await func(*args, **kwargs)
                return result
            except Exception as e:
                status = "error"
                raise
            finally:
                duration = time.time() - start_time
                prediction_duration_seconds.labels(endpoint=endpoint).observe(duration)
                prediction_requests_total.labels(endpoint=endpoint, status=status).inc()
        
        return wrapper
    return decorator


def track_model_inference():
    """Decorator to track model inference latency"""
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                return result
            finally:
                duration = time.time() - start_time
                model_inference_latency.observe(duration)
        
        return wrapper
    return decorator


def track_redis_operation(operation: str):
    """Decorator to track Redis operations"""
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            start_time = time.time()
            status = "success"
            
            try:
                result = await func(*args, **kwargs)
                return result
            except Exception as e:
                status = "error"
                raise
            finally:
                duration = time.time() - start_time
                redis_latency_seconds.labels(operation=operation).observe(duration)
                redis_operations_total.labels(operation=operation, status=status).inc()
        
        return wrapper
    return decorator


class MetricsManager:
    """Manager for updating model performance metrics"""
    
    @staticmethod
    def update_model_metrics(metrics: dict):
        """Update model performance metrics"""
        if 'auc' in metrics:
            model_auc_score.set(metrics['auc'])
    
    @staticmethod
    def record_prediction(risk_level: str, model_version: str):
        """Record a prediction"""
        prediction_risk_distribution.labels(risk_level=risk_level).inc()
        model_predictions_total.labels(model_version=model_version).inc()
    
    @staticmethod
    def set_drift_status(drift_detected: bool):
        """Set model drift detection status"""
        model_drift_detected.set(1 if drift_detected else 0)
    
    @staticmethod
    def record_batch_size(size: int):
        """Record batch prediction size"""
        batch_size_distribution.observe(size)
    
    @staticmethod
    def record_error(endpoint: str, error_type: str):
        """Record an API error"""
        api_errors_total.labels(endpoint=endpoint, error_type=error_type).inc()
    
    @staticmethod
    def update_uptime(uptime_seconds: float):
        """Update system uptime"""
        system_uptime_seconds.set(uptime_seconds)
    
    @staticmethod
    def set_app_info(version: str, model_version: str):
        """Set application info"""
        app_info.info({
            'version': version,
            'model_version': model_version,
            'service': 'iit-prediction'
        })
