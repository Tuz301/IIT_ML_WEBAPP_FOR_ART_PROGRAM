"""
Pydantic models for request/response validation
"""
from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum


class VisitData(BaseModel):
    """Patient visit record"""
    dateStarted: str
    voided: int = 0
    visitType: Optional[str] = None


class EncounterData(BaseModel):
    """Patient encounter record"""
    encounterUuid: str
    encounterDatetime: str
    encounterType: Optional[str] = None
    pmmForm: Optional[str] = None
    voided: int = 0


class ObservationData(BaseModel):
    """Clinical observation record"""
    obsDatetime: str
    variableName: str
    valueNumeric: Optional[float] = None
    valueText: Optional[str] = None
    valueCoded: Optional[str] = None
    encounterUuid: Optional[str] = None
    voided: int = 0


class DemographicsData(BaseModel):
    """Patient demographic information"""
    patientUuid: str
    birthdate: str
    gender: str
    stateProvince: Optional[str] = None
    cityVillage: Optional[str] = None
    phoneNumber: Optional[str] = None


class MessageData(BaseModel):
    """Complete patient message data structure"""
    demographics: DemographicsData
    visits: List[VisitData]
    encounters: List[EncounterData]
    obs: List[ObservationData]


class PatientJSON(BaseModel):
    """Complete patient JSON structure from IHVN system"""
    messageData: MessageData
    
    class Config:
        json_schema_extra = {
            "example": {
                "messageData": {
                    "demographics": {
                        "patientUuid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                        "birthdate": "1985-06-15 00:00:00",
                        "gender": "F",
                        "stateProvince": "Lagos",
                        "cityVillage": "Ikeja",
                        "phoneNumber": "+234801234567"
                    },
                    "visits": [
                        {
                            "dateStarted": "2024-10-01 10:30:00",
                            "voided": 0,
                            "visitType": "CLINICAL"
                        }
                    ],
                    "encounters": [
                        {
                            "encounterUuid": "enc-uuid-123",
                            "encounterDatetime": "2024-10-01 10:30:00",
                            "pmmForm": "Pharmacy Order Form",
                            "voided": 0
                        }
                    ],
                    "obs": [
                        {
                            "obsDatetime": "2024-10-01 10:30:00",
                            "variableName": "Medication duration",
                            "valueNumeric": 90.0,
                            "voided": 0
                        }
                    ]
                }
            }
        }


class RiskLevel(str, Enum):
    """IIT risk level classification"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class IITPrediction(BaseModel):
    """Single patient IIT prediction response"""
    patient_uuid: str
    iit_risk_score: float = Field(..., ge=0.0, le=1.0, description="Probability of IIT (0-1)")
    risk_level: RiskLevel
    confidence: float = Field(..., ge=0.0, le=1.0, description="Model confidence score")
    prediction_timestamp: datetime
    features_used: Dict[str, Any]
    model_version: str
    
    @validator('risk_level', pre=True, always=True)
    def determine_risk_level(cls, v, values):
        """Automatically determine risk level from score"""
        if 'iit_risk_score' not in values:
            return v
        
        score = values['iit_risk_score']
        if score >= 0.75:
            return RiskLevel.CRITICAL
        elif score >= 0.5:
            return RiskLevel.HIGH
        elif score >= 0.3:
            return RiskLevel.MEDIUM
        else:
            return RiskLevel.LOW
    
    class Config:
        json_schema_extra = {
            "example": {
                "patient_uuid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                "iit_risk_score": 0.68,
                "risk_level": "high",
                "confidence": 0.85,
                "prediction_timestamp": "2025-10-30T21:44:24",
                "features_used": {
                    "age": 39,
                    "days_since_last_refill": 45,
                    "last_days_supply": 30
                },
                "model_version": "1.0.0"
            }
        }


class BatchPredictionRequest(BaseModel):
    """Batch prediction request"""
    patients: List[PatientJSON] = Field(..., max_length=100)
    
    @validator('patients')
    def validate_batch_size(cls, v):
        if len(v) > 100:
            raise ValueError("Batch size cannot exceed 100 patients")
        return v


class BatchPrediction(BaseModel):
    """Batch prediction response"""
    predictions: List[IITPrediction]
    total_processed: int
    failed_count: int
    processing_time_seconds: float
    batch_id: str


class ModelMetrics(BaseModel):
    """Current model performance metrics"""
    model_version: str
    auc: float
    precision: float
    recall: float
    f1: float
    brier_score: float
    sensitivity: float
    specificity: float
    last_trained: Optional[datetime] = None
    total_predictions: int
    drift_detected: bool = False


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    version: str
    timestamp: datetime
    model_loaded: bool
    redis_connected: bool
    uptime_seconds: float


class ErrorResponse(BaseModel):
    """Standard error response"""
    error: str
    detail: Optional[str] = None
    timestamp: datetime
    request_id: Optional[str] = None
