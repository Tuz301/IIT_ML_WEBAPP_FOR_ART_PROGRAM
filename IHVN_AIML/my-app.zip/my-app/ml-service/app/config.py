"""
Configuration management for IIT Prediction ML Service
"""
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    """Application settings with environment variable support"""
    
    # API Configuration
    api_title: str = "IIT Prediction ML Service"
    api_version: str = "1.0.0"
    api_description: str = "Production-ready ML service for predicting IIT (Interruption in Treatment) risk"
    debug: bool = False
    
    # Model Configuration
    model_path: str = "./models/iit_lightgbm_model.txt"
    preprocessing_path: str = "./models/preprocessing_meta.joblib"
    model_manifest_path: str = "./models/model_manifest.json"
    
    # Feature Store Configuration
    redis_host: str = "redis"
    redis_port: int = 6379
    redis_db: int = 0
    redis_password: str | None = None
    feature_store_ttl: int = 86400  # 24 hours
    
    # Database Configuration (for future use)
    postgres_host: str = "postgres"
    postgres_port: int = 5432
    postgres_db: str = "iit_ml_service"
    postgres_user: str = "ml_service"
    postgres_password: str = "changeme"
    
    # Performance Configuration
    max_batch_size: int = 100
    prediction_timeout: float = 30.0
    
    # Monitoring Configuration
    log_level: str = "INFO"
    enable_metrics: bool = True
    metrics_port: int = 9090
    
    # Security Configuration
    api_key_enabled: bool = False
    api_key_header: str = "X-API-Key"
    cors_origins: list[str] = ["*"]
    
    # IIT Prediction Specific
    iit_grace_period: int = 28
    prediction_window: int = 90
    default_threshold: float = 0.5
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance"""
    return Settings()
