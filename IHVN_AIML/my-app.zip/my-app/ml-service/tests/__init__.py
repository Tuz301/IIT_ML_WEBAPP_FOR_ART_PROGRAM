"""
Test suite for IIT Prediction ML Service
"""
