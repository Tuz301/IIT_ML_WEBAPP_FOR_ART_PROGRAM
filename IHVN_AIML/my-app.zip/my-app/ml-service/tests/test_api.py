"""
API endpoint tests for IIT Prediction ML Service
"""
import pytest
from fastapi.testclient import TestClient
from datetime import datetime

from app.main import app

client = TestClient(app)


class TestHealthEndpoints:
    """Test health and monitoring endpoints"""
    
    def test_health_check(self):
        """Test health check endpoint"""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "version" in data
        assert "uptime_seconds" in data
    
    def test_root_endpoint(self):
        """Test root endpoint"""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert "service" in data
        assert "endpoints" in data
    
    def test_metrics_endpoint(self):
        """Test Prometheus metrics endpoint"""
        response = client.get("/metrics")
        assert response.status_code == 200
        assert "text/plain" in response.headers["content-type"]
    
    def test_model_metrics(self):
        """Test model metrics endpoint"""
        response = client.get("/model_metrics")
        assert response.status_code == 200
        data = response.json()
        assert "auc" in data
        assert "precision" in data
        assert "recall" in data
        assert "model_version" in data


class TestPredictionEndpoints:
    """Test prediction endpoints"""
    
    @pytest.fixture
    def sample_patient_data(self):
        """Sample patient data for testing"""
        return {
            "messageData": {
                "demographics": {
                    "patientUuid": "test-patient-123",
                    "birthdate": "1985-06-15 00:00:00",
                    "gender": "F",
                    "stateProvince": "Lagos",
                    "cityVillage": "Ikeja",
                    "phoneNumber": "+234801234567"
                },
                "visits": [
                    {
                        "dateStarted": "2024-10-01 10:30:00",
                        "voided": 0
                    }
                ],
                "encounters": [
                    {
                        "encounterUuid": "enc-123",
                        "encounterDatetime": "2024-10-01 10:30:00",
                        "pmmForm": "Pharmacy Order Form",
                        "voided": 0
                    }
                ],
                "obs": [
                    {
                        "obsDatetime": "2024-10-01 10:30:00",
                        "variableName": "Medication duration",
                        "valueNumeric": 90.0,
                        "voided": 0
                    }
                ]
            }
        }
    
    def test_predict_single_patient(self, sample_patient_data):
        """Test single patient prediction"""
        response = client.post("/predict", json=sample_patient_data)
        assert response.status_code == 200
        
        data = response.json()
        assert "patient_uuid" in data
        assert "iit_risk_score" in data
        assert "risk_level" in data
        assert "confidence" in data
        assert "model_version" in data
        
        # Validate risk score range
        assert 0.0 <= data["iit_risk_score"] <= 1.0
        assert 0.0 <= data["confidence"] <= 1.0
    
    def test_batch_predict(self, sample_patient_data):
        """Test batch prediction"""
        batch_request = {
            "patients": [sample_patient_data, sample_patient_data]
        }
        
        response = client.post("/batch_predict", json=batch_request)
        assert response.status_code == 200
        
        data = response.json()
        assert "predictions" in data
        assert "total_processed" in data
        assert "batch_id" in data
        assert len(data["predictions"]) == 2
    
    def test_batch_size_validation(self, sample_patient_data):
        """Test batch size limit validation"""
        # Create oversized batch
        batch_request = {
            "patients": [sample_patient_data] * 101
        }
        
        response = client.post("/batch_predict", json=batch_request)
        assert response.status_code == 422  # Validation error


class TestDataValidation:
    """Test input data validation"""
    
    def test_invalid_patient_data(self):
        """Test prediction with invalid patient data"""
        invalid_data = {
            "messageData": {
                "demographics": {
                    "patientUuid": "test"
                    # Missing required fields
                }
            }
        }
        
        response = client.post("/predict", json=invalid_data)
        assert response.status_code == 422
    
    def test_missing_message_data(self):
        """Test prediction with missing messageData"""
        response = client.post("/predict", json={})
        assert response.status_code == 422


@pytest.mark.asyncio
class TestAsyncOperations:
    """Test asynchronous operations"""
    
    async def test_concurrent_predictions(self):
        """Test concurrent prediction handling"""
        # This would test async behavior in production
        pass


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
